package com.example.tecsup.repaso_pokeapi;

public class Sprite {
    String back_default;
    String front_default;

}

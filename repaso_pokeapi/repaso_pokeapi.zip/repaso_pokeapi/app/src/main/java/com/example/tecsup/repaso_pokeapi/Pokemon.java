package com.example.tecsup.repaso_pokeapi;

public class Pokemon {
    int id;
    String name;
    Sprite sprites;
}

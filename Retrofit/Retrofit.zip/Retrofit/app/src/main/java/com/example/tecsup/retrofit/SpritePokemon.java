package com.example.tecsup.retrofit;

public class SpritePokemon {
    String front_default;

    public SpritePokemon() {
    }

    public String getFront_default() {
        return front_default;
    }

    public void setFront_default(String front_default) {
        this.front_default = front_default;
    }
}
